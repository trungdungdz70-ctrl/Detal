// language: Swift, file: ContentView.swift

import SwiftUI

struct ContentView: View {
    // Trạng thái Menu
    @State private var aimbotEnabled: Bool = true
    @State private var selectedBone: String = "Head" // Mặc định chọn Đầu
    
    // Trạng thái Patch
    @State private var showAlert: Bool = false
    @State private var alertMessage: String = ""
    
    var body: some View {
        ScrollView {
            VStack(spacing: 20) {
                
                // --- KHUNG AIM SYSTEM ---
                VStack(alignment: .leading, spacing: 15) {
                    
                    // Tiêu đề AIM SYSTEM
                    HStack {
                        Image(systemName: "target")
                            .foregroundColor(.white)
                        Text("AIM SYSTEM")
                            .font(.subheadline)
                            .fontWeight(.bold)
                            .foregroundColor(.white)
                    }
                    
                    // Nút bật/tắt Aimbot
                    Toggle(isOn: $aimbotEnabled) {
                        HStack {
                            Image(systemName: "flame.fill")
                                .foregroundColor(.white)
                            Text("Hệ Thống Aimbot")
                                .font(.body)
                                .fontWeight(.medium)
                                .foregroundColor(.white)
                        }
                    }
                    .toggleStyle(SwitchToggleStyle(tint: .white))
                    .padding(.vertical, 5)
                    
                    Divider().background(Color.gray.opacity(0.3))
                    
                    // Mục chọn Vị Trí Ngắm
                    Text("Vị Trí Ngắm")
                        .font(.subheadline)
                        .fontWeight(.semibold)
                        .foregroundColor(.gray)
                        .padding(.top, 5)
                    
                    // 3 Nút chọn Head / Neck / Body
                    HStack(spacing: 10) {
                        // Nút Head
                        Button(action: { 
                            selectedBone = "Head" 
                            // Gọi hàm đổi vị trí aim sang Head ở đây
                        }) {
                            Text("Đầu (Head)")
                                .fontWeight(.bold)
                                .frame(maxWidth: .infinity)
                                .padding(.vertical, 12)
                                .background(selectedBone == "Head" ? Color.white : Color.black)
                                .foregroundColor(selectedBone == "Head" ? Color.black : Color.white)
                                .cornerRadius(10)
                                .overlay(RoundedRectangle(cornerRadius: 10).stroke(Color.gray.opacity(0.5), lineWidth: 1))
                        }
                        
                        // Nút Neck
                        Button(action: { 
                            selectedBone = "Neck" 
                            // Gọi hàm đổi vị trí aim sang Neck ở đây
                        }) {
                            Text("Cổ (Neck)")
                                .fontWeight(.bold)
                                .frame(maxWidth: .infinity)
                                .padding(.vertical, 12)
                                .background(selectedBone == "Neck" ? Color.white : Color.black)
                                .foregroundColor(selectedBone == "Neck" ? Color.black : Color.white)
                                .cornerRadius(10)
                                .overlay(RoundedRectangle(cornerRadius: 10).stroke(Color.gray.opacity(0.5), lineWidth: 1))
                        }
                        
                        // Nút Body
                        Button(action: { 
                            selectedBone = "Body" 
                            // Gọi hàm đổi vị trí aim sang Body ở đây
                        }) {
                            Text("Người (Body)")
                                .fontWeight(.bold)
                                .frame(maxWidth: .infinity)
                                .padding(.vertical, 12)
                                .background(selectedBone == "Body" ? Color.white : Color.black)
                                .foregroundColor(selectedBone == "Body" ? Color.black : Color.white)
                                .cornerRadius(10)
                                .overlay(RoundedRectangle(cornerRadius: 10).stroke(Color.gray.opacity(0.5), lineWidth: 1))
                        }
                    }
                    
                    // --- NÚT ÁP DỤNG PATCH ---
                    Button(action: {
                        applyPatch()
                    }) {
                        HStack {
                            Image(systemName: "bolt.circle.fill")
                            Text("ÁP DỤNG PATCH")
                        }
                        .font(.headline)
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color.white)
                        .foregroundColor(.black)
                        .cornerRadius(10)
                    }
                    .padding(.top, 10)
                    
                }
                .padding()
                .background(Color(red: 0.12, green: 0.12, blue: 0.12)) // Nền xám tối như ảnh
                .cornerRadius(15)
                .padding(.horizontal)
                
            }
            .padding(.top)
        }
        .background(Color(red: 0.05, green: 0.05, blue: 0.05).edgesIgnoringSafeArea(.all))
        .alert(isPresented: $showAlert) {
            Alert(title: Text("TrungDung Menu"), message: Text(alertMessage), dismissButton: .default(Text("OK")))
        }
    }
    
    // --- HÀM XỬ LÝ PATCH ---
    func applyPatch() {
        // TỰ ĐỘNG TẠO ĐƯỜNG DẪN DỰA VÀO VỊ TRÍ ĐANG CHỌN
        var pathToPatch = ""
        
        if selectedBone == "Head" {
            pathToPatch = "/var/mobile/Documents/aimhead.bin"
        } else if selectedBone == "Neck" {
            pathToPatch = "/var/mobile/Documents/aimneck.bin"
        } else if selectedBone == "Body" {
            pathToPatch = "/var/mobile/Documents/aimbody.bin"
        }
        
        // Kiểm tra file trên máy
        if FileManager.default.fileExists(atPath: pathToPatch) {
            // ==========================================
            // GỌI HÀM TIÊM FILE VÀO GAME TẠI ĐÂY
            // Ví dụ: ExploitManager.shared.inject(path: pathToPatch)
            // ==========================================
            
            alertMessage = "Đã áp dụng Patch cho vị trí: \(selectedBone)\nĐường dẫn: \(pathToPatch)"
            showAlert = true
        } else {
            alertMessage = "LỖI: Không tìm thấy file patch tại:\n\(pathToPatch)"
            showAlert = true
        }
    }
}